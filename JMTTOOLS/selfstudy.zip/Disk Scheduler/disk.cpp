#define SCALE 100
#define LEFTMIN -200000
#define RIGHTMAX 300000

typedef struct Node {
	int data;
	int next;
};

int Head[100000 / SCALE + 5];
Node List[100005];
int queue[100005], front, rear;
int N, H, M;

bool flag[100005];
bool dir;

void add(int val) {
	List[M].data = val;
	List[M].next = Head[val / SCALE];
	Head[val / SCALE] = M++;
}

void remove(int val) {
	int prev = 0;
	int cur = Head[val / SCALE];

	while (cur) {
		if (List[cur].data == val) {
			if (prev == 0) {
				Head[val / SCALE] = List[cur].next;
			}
			else {
				List[prev].next = List[cur].next;
			}

			break;
		}

		prev = cur;
		cur = List[cur].next;
	}
}

int findLeft(int val) {
	int max = LEFTMIN;

	for (int i = val / SCALE; i >= 0 && max == LEFTMIN; --i) {
		int cur = Head[i];

		while (cur) {
			if (List[cur].data <= val) {
				if (max < List[cur].data) {
					max = List[cur].data;
				}
			}

			cur = List[cur].next;
		}
	}

	return max;
}

int findRight(int val) {
	int min = RIGHTMAX;

	for (int i = val / SCALE; i <= N / SCALE && min == RIGHTMAX; ++i) {
		int cur = Head[i];

		while (cur) {
			if (List[cur].data >= val) {
				if (min > List[cur].data) {
					min = List[cur].data;
				}
			}

			cur = List[cur].next;
		}
	}

	return min;
}


void init(int track_size, int head) {
	N = track_size;
	H = head;
	M = 1;
	dir = false;
	front = rear = 0;

	for (int i = 0; i < (100000 / SCALE + 5); ++i) {
		Head[i] = 0;
	}

	for (int i = 0; i <= track_size; ++i) {
		flag[i] = false;
	}
}


void request(int track) {
	queue[rear++] = track;
	add(track);
}

int fcfs() {
	int qValue;

	while (front < rear) {
		qValue = queue[front++];

		if (!flag[qValue]) {
			break;
		}
	}

	flag[qValue] = true;
	remove(qValue);

	return H = qValue;
}


int sstf() {
	int left = findLeft(H);
	int right = findRight(H);

	if (H - left <= right - H) {
		H = left;
	}
	else {
		H = right;
	}

	flag[H] = true;
	remove(H);

	return H;
}

int look() {
	int left = findLeft(H);
	int right = findRight(H);

	if (!dir) {
		H = left;

		if (left == LEFTMIN) {
			dir = true;
			H = right;
		}
	}
	else {
		H = right;

		if (right == RIGHTMAX) {
			dir = false;
			H = left;
		}
	}

	flag[H] = true;
	remove(H);

	return H;
}

int clook() {
	int left = findLeft(H);

	if (left == LEFTMIN) {
		left = findLeft(N);
	}

	H = left;
	flag[H] = true;
	remove(H);

	return H;
}
