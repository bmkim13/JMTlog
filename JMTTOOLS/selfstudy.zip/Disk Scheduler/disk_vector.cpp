#include <vector>
#include <queue>

#define SCALE 100
#define LEFTMIN -200000
#define RIGHTMAX 300000

using namespace std;

vector<int> disks[100000 / SCALE + 5];
queue<int> Q;
int N, H;
bool dir, flag[100005];

void remove(int val) {
	for (int i = 0; i < disks[val / SCALE].size(); ++i) {
		if (disks[val / SCALE][i] == val) {
			disks[val / SCALE].erase(disks[val / SCALE].begin() + i);
			break;
		}
	}
}

int findLeft(int val) {
	int max = LEFTMIN;

	for (int i = val / SCALE; i >= 0 && max == LEFTMIN; --i) {
		for (int j = 0; j < disks[i].size(); ++j) {
			if (disks[i][j] <= val) {
				if (max < disks[i][j]) {
					max = disks[i][j];
				}
			}
		}
	}

	return max;
}

int findRight(int val) {
	int min = RIGHTMAX;

	for (int i = val / SCALE; i <= N / SCALE && min == RIGHTMAX; ++i) {
		for (int j = 0; j < disks[i].size(); ++j) {
			if (disks[i][j] >= val) {
				if (min > disks[i][j]) {
					min = disks[i][j];
				}
			}
		}
	}

	return min;
}

void init(int track_size, int head) {
	N = track_size;
	H = head;
	dir = false;

	for (int i = 0; i < (100000 / SCALE + 5); ++i) {
		disks[i].clear();
	}

	for (int i = 0; i <= track_size; ++i) {
		flag[i] = false;
	}

	while (!Q.empty()) {
		Q.pop();
	}
}

void request(int track) {
	Q.push(track);
	disks[track / SCALE].push_back(track);
}

int fcfs() {
	int qValue;

	while (!Q.empty()) {
		qValue = Q.front();
		Q.pop();

		if (!flag[qValue]) {
			break;
		}
	}

	flag[qValue] = true;
	remove(qValue);

	return H = qValue;
}

int sstf() {
	int left = findLeft(H);
	int right = findRight(H);

	if (H - left <= right - H) {
		H = left;
	}
	else {
		H = right;
	}

	flag[H] = true;
	remove(H);

	return H;
}

int look() {
	int left = findLeft(H);
	int right = findRight(H);

	if (!dir) {
		H = left;

		if (left == LEFTMIN) {
			dir = true;
			H = right;
		}
	}
	else {
		H = right;

		if (right == RIGHTMAX) {
			dir = false;
			H = left;
		}
	}

	flag[H] = true;
	remove(H);

	return H;
}


int clook() {
	int left = findLeft(H);

	if (left == LEFTMIN) {
		left = findLeft(N);
	}

	H = left;
	flag[H] = true;
	remove(H);

	return H;
}