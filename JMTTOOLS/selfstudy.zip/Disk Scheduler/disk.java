public class UserSolution {

	private static final int SCALE = 100;
	private static final int LEFTMIN = -200000;
	private static final int RIGHTMAX = 300000;
	
	class Node {
		int data;
		Node next;
		
		Node(int data, Node next) {
			this.data = data;
			this.next = next;
		}
	}
	
	Node[] Head = new Node [100000 / SCALE + 5];
	private int[] queue = new int [100005];
	private int front, rear;
	private int N, H;
	private boolean dir;
	private boolean[] flag;
	
	private void add(int val) {
		Node newNode = new Node(val, Head[val / SCALE].next); 
		Head[val / SCALE].next = newNode;
	}
	
	private void remove(int val) {
		Node prev = null;
		Node cur = Head[val / SCALE].next;
		
		while (cur != null) {
			if (cur.data == val) {
				if (prev == null) {
					Head[val / SCALE].next = cur.next;
				} else {
					prev.next = cur.next;
				}
				
				break;
			}
			
			prev = cur;
			cur = cur.next;
		}
	}

	private int findLeft(int val) {
		int max = LEFTMIN;
		
		for (int i = val / SCALE ; i >= 0 && max == LEFTMIN ; --i) {
			Node cur = Head[i].next;
			
			while (cur != null) {
				if (cur.data <= val) {
					if (max < cur.data) {
						max = cur.data;
					}
				}
				
				cur = cur.next; 
			}
		}
		
		return max;
	}
	
	private int findRight(int val) {
		int min = RIGHTMAX;
		
		for (int i = val / SCALE; i <= N / SCALE && min == RIGHTMAX; ++i) {
			Node cur = Head[i].next;
			
			while (cur != null) {
				if (cur.data >= val) {
					if (min > cur.data) {
						min = cur.data;
					}
				}
				
				cur = cur.next;
			}
		}
		
		return min;
	}

	public void init(int track_size, int head) {
		N = track_size;
		H = head;
		dir = false;
		front = rear = 0;
		
		for (int i = 0; i < (N / SCALE + 5); ++i) {
			Head[i] = new Node(-1, null);
		}
		flag = new boolean [N];
	}

	public void request(int track) {
		queue[rear++] = track;
		add(track);
	}

	public int fcfs() {
		int qValue = 0;
		
		while (front < rear) {
			qValue = queue[front++];
			
			if (!flag[qValue]) {
				break;
			}
		}
		
		flag[qValue] = true;
		remove(qValue);

		return H = qValue;
	}

	public int sstf() {
		int left = findLeft(H);
		int right = findRight(H);
		
		if (H - left <= right - H) {
			H = left;
		} else {
			H = right;
		}
		
		flag[H] = true;
		remove(H);

		return H;
	}

	public int look() {
		int left = findLeft(H);
		int right = findRight(H);
		
		if (!dir) {
			H = left;
			
			if (left == LEFTMIN) {
				dir = true;
				H = right;
			}
		} else {
			H = right;
			
			if (right == RIGHTMAX) {
				dir = false;
				H = left;
			}
		}
		
		flag[H] = true;
		remove(H);

		return H;
	}

	public int clook() {
		int left = findLeft(H);
		
		if (left == LEFTMIN) {
			left = findLeft(N);
		}
		
		H = left;
		flag[H] = true;
		remove(H);

		return H;
	}

}
