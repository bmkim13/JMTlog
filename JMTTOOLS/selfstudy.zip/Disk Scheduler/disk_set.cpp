#include <set>
#include <queue>

using namespace std;

set<int> S;
queue<int> Q;

int N, H;

bool flag[100005];
bool dir;

void init(int track_size, int head) {
	N = track_size;
	H = head;
	dir = false;

	S.clear();

	while (!Q.empty()) {
		Q.pop();
	}

	for (int i = 0; i <= track_size; ++i) {
		flag[i] = false;
	}
}


void request(int track) {
	Q.push(track);
	S.insert(track);
}

int fcfs() {

	while (!Q.empty()) {
		if (!flag[Q.front()]) {
			break;
		}

		Q.pop();
	}

	H = Q.front();
	Q.pop();

	flag[H] = true;
	S.erase(H);

	return H;
}


int sstf() {
	set<int>::iterator left = S.lower_bound(H);
	set<int>::iterator right = S.upper_bound(H);

	if (left == S.end() || *left > H) {
		--left;
	}

	if (left == S.end()) {
		H = *right;
	}
	else if (right == S.end()) {
		H = *left;
	}
	else if (H - *left <= *right - H) {
		H = *left;
	}
	else {
		H = *right;
	}

	flag[H] = true;
	S.erase(H);

	return H;
}

int look() {
	set<int>::iterator left = S.lower_bound(H);
	set<int>::iterator right = S.upper_bound(H);

	if (left == S.end() || *left > H) {
		--left;
	}

	if ((!dir && left == S.end()) || (dir && right == S.end())) {
		dir ^= true;
	}

	if (dir) {
		H = *right;
	}
	else {
		H = *left;
	}

	flag[H] = true;
	S.erase(H);

	return H;
}

int clook() {
	set<int>::iterator left = S.lower_bound(H);

	if (left == S.end() || *left > H) {
		--left;

		if (left == S.end()) {
			--left;
		}
	}

	H = *left;

	flag[H] = true;
	S.erase(H);

	return H;
}