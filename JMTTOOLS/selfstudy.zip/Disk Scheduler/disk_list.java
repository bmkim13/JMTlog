import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class UserSolution {

	private static final int SCALE = 100;
	private static final int LEFTMIN = -200000;
	private static final int RIGHTMAX = 300000;

	List<Integer>[] disks = new ArrayList[100000 / SCALE + 5];
	Queue<Integer> Q;
	private int N, H;
	private boolean dir;
	private boolean[] flag;
	
	private void remove(int val) {
	    for (int i = 0; i < disks[val / SCALE].size(); ++i) {
	        if (disks[val / SCALE].get(i) == val) {
	        	disks[val / SCALE].remove(i);
	        	break;
	        }
	    }

	}

	private int findLeft(int val) {
		int max = LEFTMIN;
		
		for (int i = val / SCALE ; i >= 0 && max == LEFTMIN ; --i) {
			for (int disk : disks[i]) {
				if (disk <= val && max < disk) {
					max = disk;
				}
			}
		}
		
		return max;
	}
	
	private int findRight(int val) {
		int min = RIGHTMAX;
		
		for (int i = val / SCALE; i <= N / SCALE && min == RIGHTMAX; ++i) {
			for (int disk : disks[i]) {
				if (disk >= val && min > disk) {
					min = disk;
				}
			}
		}
		
		return min;
	}

	public void init(int track_size, int head) {
		N = track_size;
		H = head;
		dir = false;
		
		for (int i = 0; i < (N / SCALE + 1); ++i) {
			disks[i] = new ArrayList<Integer>();
		}
		
		flag = new boolean [N];
		Q = new LinkedList<Integer>();
	}

	public void request(int track) {
		Q.add(track);
		disks[track / SCALE].add(track);
	}

	public int fcfs() {
		int qValue = 0;
		
		while (!Q.isEmpty()) {
			qValue = Q.poll();
			
			if (!flag[qValue]) {
				break;
			}
		}
		
		flag[qValue] = true;
		remove(qValue);

		return H = qValue;
	}

	public int sstf() {
		int left = findLeft(H);
		int right = findRight(H);
		
		if (H - left <= right - H) {
			H = left;
		} else {
			H = right;
		}
		
		flag[H] = true;
		remove(H);

		return H;
	}

	public int look() {
		int left = findLeft(H);
		int right = findRight(H);
		
		if (!dir) {
			H = left;
			
			if (left == LEFTMIN) {
				dir = true;
				H = right;
			}
		} else {
			H = right;
			
			if (right == RIGHTMAX) {
				dir = false;
				H = left;
			}
		}
		
		flag[H] = true;
		remove(H);

		return H;
	}

	public int clook() {
		int left = findLeft(H);
		
		if (left == LEFTMIN) {
			left = findLeft(N);
		}
		
		H = left;
		flag[H] = true;
		remove(H);

		return H;
	}

}