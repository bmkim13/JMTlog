﻿public class UserSolution {   
  private static final int MAX_N = 700;

  class Line {
    char str[] = new char[MAX_N];
    int len;
    Line prev;
    Line next;
  }

  Line Pool[] = new Line[MAX_N];
  int PoolCnt;
  Line Head;
  Line CurLine;
  int CurC;
  
  UserSolution() {
    for (int i = 0; i < Pool.length; ++i)
      Pool[i] = new Line();
  }

  public void init(int n){
    PoolCnt = 0;
    
    Head = Pool[PoolCnt++];
    Head.prev = Head.next = null;
    Head.len = 0;
    CurLine = Head;
    CurC = 0;
  }
  
  public void input_char(char in_char){
    if (CurC < CurLine.len) {
      for (int i = CurLine.len; i > CurC; --i)
        CurLine.str[i] = CurLine.str[i - 1];
    }

    CurLine.str[CurC++] = in_char;
    CurLine.len++;
  }
  
  public void input_newline(){
    Line newline = Pool[PoolCnt++];
    
    Line tmp = CurLine.next;
    CurLine.next = newline;
    newline.prev = CurLine;
    newline.next = tmp;
    newline.len = 0;
    if (tmp != null)
      tmp.prev = newline;        
    
    if (CurC < CurLine.len) {
      int i;
      for (i = 0; CurC + i < CurLine.len; ++i) {
        newline.str[i] = CurLine.str[CurC + i];
      }
      newline.len = i;
      CurLine.len = CurC;
    }

    CurLine = newline;
    CurC = 0;
  }
  
  public void move_cursor(int direction){ // 0: Up, 1: Down, 2: Left, 3: Right
    switch (direction) {
    case 0:
      if (CurLine.prev != null) {
        CurLine = CurLine.prev;
        if (CurC > CurLine.len)
          CurC = CurLine.len;
      }
      break;
    case 1:
      if (CurLine.next != null) {
        CurLine = CurLine.next;
        if (CurC > CurLine.len)
          CurC = CurLine.len;
      }            
      break;
    case 2:
      if (CurC > 0) {
        --CurC;
      }
      else {
        if (CurLine.prev != null) {
          CurLine = CurLine.prev;
          CurC = CurLine.len;
        }
      }
      break;
    case 3:
      if (CurC < CurLine.len) {
        ++CurC;
      }
      else {
        if (CurLine.next != null) {
          CurLine = CurLine.next;
          CurC = 0;
        }
      }
      break;
    }
  }
  
  public char get_char(int row, int column){        
    Line line = Head;
    for (int i = 0; i < row -1; ++i)
      line = line.next;

    return line.str[column - 1];
  }
}
