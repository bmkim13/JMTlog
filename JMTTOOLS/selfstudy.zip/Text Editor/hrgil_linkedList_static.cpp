#define MAX_N 700

struct Line {
  char str[MAX_N];
  int len;
  Line* prev;
  Line* next;
};

Line Pool[MAX_N];
int PoolCnt;
Line* Head = 0;
Line* CurLine;
int CurC;

void init(int n){
  PoolCnt = 0;

  Head = &Pool[PoolCnt++];
  Head->prev = Head->next = 0;
  Head->len = 0;
  CurLine = Head;
  CurC = 0;
}

void input_char(char in_char){
  if (CurC < CurLine->len) {
    for (register int i = CurLine->len; i > CurC; --i)
      CurLine->str[i] = CurLine->str[i - 1];
  }

  CurLine->str[CurC++] = in_char;
  CurLine->len++;
}

void input_newline(){
  register Line* newline = &Pool[PoolCnt++];

  Line* tmp = CurLine->next;
  CurLine->next = newline;
  newline->prev = CurLine;
  newline->next = tmp;
  newline->len = 0;
  if (tmp)
    tmp->prev = newline;

  if (CurC < CurLine->len) {
    register int i;
    for (i = 0; CurC + i < CurLine->len; ++i) {
      newline->str[i] = CurLine->str[CurC + i];
    }
    newline->len = i;
    CurLine->len = CurC;
  }

  CurLine = newline;
  CurC = 0;
}

void move_cursor(int direction){ // 0: Up, 1: Down, 2: Left, 3: Right
  switch (direction) {
  case 0:
    if (CurLine->prev) {
      CurLine = CurLine->prev;
      if (CurC > CurLine->len)
        CurC = CurLine->len;
    }
    break;
  case 1:
    if (CurLine->next) {
      CurLine = CurLine->next;
      if (CurC > CurLine->len)
        CurC = CurLine->len;
    }
    break;
  case 2:
    if (CurC > 0) {
      --CurC;
    }
    else {
      if (CurLine->prev) {
        CurLine = CurLine->prev;
        CurC = CurLine->len;
      }
    }
    break;
  case 3:
    if (CurC < CurLine->len) {
      ++CurC;
    }
    else {
      if (CurLine->next) {
        CurLine = CurLine->next;
        CurC = 0;
      }
    }
    break;
  }
}

char get_char(int row, int column){
  register Line* pLine = Head;
  for (register int i = 0; i < row - 1; ++i)
    pLine = pLine->next;

  return pLine->str[column - 1];
}