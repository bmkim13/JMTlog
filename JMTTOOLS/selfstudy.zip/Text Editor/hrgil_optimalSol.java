public class UserSolution {   
  private static final int MAX_N = 700;

  class Node {
    char ch;
    Node prev;
    Node next;
  }

  class Line {
    Node head;
    Node tail;
    int len;
    Line prev;
    Line next;
  }

  Line[] LinePool = new Line[MAX_N];
  int LinePoolCnt;
  Node[] NodePool = new Node[MAX_N * (MAX_N + 1)];
  int NodePoolCnt;
  Line Head;
  Line CurLine;
  Node CurNode;
  int CurColIdx;
  
  UserSolution() {
    for (int i = 0; i < LinePool.length; ++i)
      LinePool[i] = new Line();

    for (int i = 0; i < NodePool.length; ++i)
      NodePool[i] = new Node();
  }

  public void init(int n){
    LinePoolCnt = 0;
    NodePoolCnt = 0;

    CurNode = NodePool[NodePoolCnt++];
    CurNode.prev = CurNode.next = null;
    CurNode.ch = 0;

    Head = LinePool[LinePoolCnt++];
    CurLine = Head;
    CurLine.head = CurLine.tail = CurNode;
    CurLine.len = 0;
    CurLine.prev = CurLine.next = null;

    CurColIdx = 0;
  }
  
  public void input_char(char in_char){
    Node newNode = NodePool[NodePoolCnt++];
    
    newNode.prev = CurNode.prev;
    newNode.next = CurNode;
    if (CurNode.prev != null) {
      CurNode.prev.next = newNode;
    } else {
      CurLine.head = newNode;
    }
    CurNode.prev = newNode;
    
    newNode.ch = in_char;
    CurLine.len++;
    CurColIdx++;
  }
  
  public void input_newline(){
    Line newLine = LinePool[LinePoolCnt++];

    newLine.prev = CurLine;
    newLine.next = CurLine.next;
    if (CurLine.next != null) {
      CurLine.next.prev = newLine;
    }
    CurLine.next = newLine;

    Node newTailNode = NodePool[NodePoolCnt++];
    newTailNode.prev = newTailNode.next = null;
    newTailNode.ch = 0;
      
    if (CurNode.ch == 0) {
      newLine.head = newLine.tail = newTailNode;
      newLine.len = 0;    
    } else {
      if (CurNode.prev != null) {
        CurNode.prev.next = newTailNode;
        newTailNode.prev = CurNode.prev;
      } else {
        CurLine.head = newTailNode;
      }
          
      newLine.head = CurNode;
      CurNode.prev = null;
      newLine.tail = CurLine.tail;
      newLine.len = CurLine.len - CurColIdx;
      
      CurLine.tail = newTailNode;
      CurLine.len = CurColIdx;
    }
    
    CurLine = newLine;
    CurNode = newLine.head;
    CurColIdx = 0;
  }
  
  public void move_cursor(int direction){ // 0: Up, 1: Down, 2: Left, 3: Right
    switch (direction) {
    case 0:
      if (CurLine.prev != null) {
        CurLine = CurLine.prev;
        
        if (CurColIdx > CurLine.len) {
          CurColIdx = CurLine.len;
          CurNode = CurLine.tail;
        } else {
          Node pNode = CurLine.head;
          for (int i = 0; i < CurColIdx; ++i) {
            pNode = pNode.next;
          }
          CurNode = pNode;
        }
      }
      break;
    case 1:
      if (CurLine.next != null) {
        CurLine = CurLine.next;
        
        if (CurColIdx > CurLine.len) {
          CurColIdx = CurLine.len;
          CurNode = CurLine.tail;
        } else {
          Node pNode = CurLine.head;
          for (int i = 0; i < CurColIdx; ++i) {
            pNode = pNode.next;
          }
          CurNode = pNode;
        }
      }
      break;

    case 2:
      if (CurColIdx > 0) {
        CurColIdx--;
        CurNode = CurNode.prev;
      } else if (CurLine.prev != null) {
        CurLine = CurLine.prev;
        CurNode = CurLine.tail;
        CurColIdx = CurLine.len;
      }
      break;
    case 3:
      if (CurColIdx < CurLine.len) {
        CurColIdx++;
        CurNode = CurNode.next;
      } else if (CurLine.next != null) {
        CurLine = CurLine.next;
        CurNode = CurLine.head;
        CurColIdx = 0;
      }
      break;
    }
  }
  
  public char get_char(int row, int column){        
    Line line = Head;
    for (int i = 0; i < row -1; ++i)
      line = line.next;
    
    Node node = line.head;
    for (int i = 0; i < column -1; ++i)
      node = node.next;
      
    return node.ch;
  }
}
