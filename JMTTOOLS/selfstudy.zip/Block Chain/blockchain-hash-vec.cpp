#define MAXSERVER	5
#define IMAGESIZE	400000

#define MAXSIZE		16

#define MAXBLOCK	15015

#define MAXCHILD    20

int cur_m;
int memory[1000000];

int getmemory(int size) {
	int ret = cur_m;
	cur_m += size;
	
	return ret;
}

struct mVector {
	int begin, cur;
	int size;
	
	void clear() {
		begin = getmemory(4);
		size = 4; cur = 0;
	}
	
	void push_back(int v) {
		if (cur == size) {
			int begin_new = getmemory(size + size);
			for (int i = 0; i < size; ++i)
				memory[begin_new + i] = memory[begin + i];
			begin = begin_new;
			size += size;
		}
		
		memory[begin + cur++] = v;
	}
	
	inline int getv(int p) {
		return memory[begin + p];
	}
	
	inline int getsize() {
		return cur;
	}
};

struct Transaction {
	unsigned char exchangeid;
	short amount;
};

struct Block {
	int   hashpreblock;
	short random;
	unsigned char size;
	Transaction trans[MAXSIZE];
	
	int   hash;
	int   hit;
	bool  available;
	int   next;
	
	int   parent;
	mVector child;
};

int   nb;
Block block[MAXBLOCK];

#define MOD	(1 << 16)

int htable[MOD];

extern int calcHash(unsigned char buf[], int pos, int size);

int get(unsigned char *image, int &v) {
	v = (image[0] << 24) + (image[1] << 16) + (image[2] << 8) + image[3];
	return 4;
}

int get(unsigned char *image, short &s) {
	s = (image[0] << 8) + image[1];
	return 2;
}

int get(unsigned char *image, unsigned char &c) {
	c = image[0];
	return 1;
}

int get(unsigned char *image, Block &block) {
	int p = 0;
	
	p += get(image + p, block.hashpreblock);
	p += get(image + p, block.random);
	p += get(image + p, block.size);
	for (int i = 0; i < block.size; ++i) {
		p += get(image + p, block.trans[i].exchangeid);
		p += get(image + p, block.trans[i].amount);
	}
	
	return p;
}

inline int getblockid(int hash) {
	if (hash == 0)
		return 0;

	int b = htable[hash % MOD];
	while (b != 0) {
		if (block[b].hash == hash)
			return b;
		b = block[b].next;
	}
	
	return -1;
}

int dfs(int id, int exchangeid) {
	int ret = 0;
	
	for (int i = 0; i < block[id].size; ++i)
		if (exchangeid == block[id].trans[i].exchangeid) {
			ret += block[id].trans[i].amount;
		}

	for (int i = 0; i < block[id].child.getsize(); ++i)
		ret += dfs(block[id].child.getv(i), exchangeid);
	
	return ret;
}

void syncBlockChain(int S, unsigned char chainimage[MAXSERVER][IMAGESIZE]) {
	cur_m = 0;
	
	block[0].child.clear();
	block[0].available = true;

	nb = 1;
	
	for (int i = 0; i < MOD; ++i)
		htable[i] = 0;

	for (int s = 0; s < S; ++s) {
		int len, hash, p = 0;
		p += get(chainimage[s] + p, len);
		while(p < len + 4) {
			int pp = p;
			p += get(chainimage[s] + p, block[nb]);
			block[nb].hash = calcHash(chainimage[s], pp, p - pp);
			int id = getblockid(block[nb].hash);
			if (id == -1) {
				int h = block[nb].hash % MOD;
				block[nb].next = htable[h];
				htable[h] = nb;
				block[nb].hit = 1;
				block[nb].child.clear();
				++nb;
			} else {
				++block[id].hit;
			}
		}
	}
	
	for (int i = 1; i < nb; ++i)
		block[i].available = block[i].hit > S / 2;
	
	for (int i = 1; i < nb; ++i)
		if (block[i].available) {
			block[i].parent = getblockid(block[i].hashpreblock);
			block[block[i].parent].child.push_back(i);
		}
}

int calcAmount(int hash, int exchangeid) {
	int id = getblockid(hash);

	return dfs(id, exchangeid);
}