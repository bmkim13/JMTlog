#define MAXSERVER	5
#define IMAGESIZE	400000

#define MAXSIZE		16

#define MAXBLOCK	100015

#define MAXCHILD    20

struct Transaction {
	unsigned char exchangeid;
	short amount;
};

struct Block {
	int   hashpreblock;
	short random;
	unsigned char size;
	Transaction trans[MAXSIZE];
	
	int   hash;
	
	int   parent;
	int   nchild;
	int   child[MAXCHILD];
};

int   nb;
Block block[MAXBLOCK];

int idx[MAXBLOCK];
int ext[MAXBLOCK];

extern int calcHash(unsigned char buf[], int pos, int size);

inline void mswap(int &a, int &b)
{
	int t = a; a = b; b = t;
}

int get(unsigned char *image, int &v) {
	v = (image[0] << 24) + (image[1] << 16) + (image[2] << 8) + image[3];
	return 4;
}

int get(unsigned char *image, short &s) {
	s = (image[0] << 8) + image[1];
	return 2;
}

int get(unsigned char *image, unsigned char &c) {
	c = image[0];
	return 1;
}

int get(unsigned char *image, Block &block) {
	int p = 0;
	
	p += get(image + p, block.hashpreblock);
	p += get(image + p, block.random);
	p += get(image + p, block.size);
	for (int i = 0; i < block.size; ++i) {
		p += get(image + p, block.trans[i].exchangeid);
		p += get(image + p, block.trans[i].amount);
	}
	
	return p;
}


void mergesort(int b, int e)
{
	if (b == e) return;
	if (e - b == 1)
	{
		if (block[idx[b]].hash > block[idx[e]].hash)
			mswap(idx[b], idx[e]);
		return;
	}
	
	int m = (b + e) / 2;
	
	mergesort(b, m);
	mergesort(m + 1, e);
	
	for (int i = b; i <= e; ++i) ext[i] = idx[i];
	
	int p1 = b, p2 = b, p3 = m + 1;
	
	while (p2 <= m && p3 <= e)
	{
		if (block[ext[p2]].hash < block[ext[p3]].hash)
		{
			idx[p1++] = ext[p2++];
		}
		else
		{
			idx[p1++] = ext[p3++];
		}
	}
	
	while (p2 <= m)
	{
		idx[p1++] = ext[p2++];
	}
	
	while (p3 <= e)
	{
		idx[p1++] = ext[p3++];
	}
}

int getblockid(int hash)
{
	int b = 0, e = nb - 1;
	
	while (b < e)
	{
		int m = (b + e) / 2;
		
		if (block[idx[m]].hash < hash)
		{
			b = m + 1;
		}
		else
		{
			e = m;
		}
	}

	return idx[b];
}

int dfs(int id, int exchangeid) {
	int ret = 0;
	
	for (int i = 0; i < block[id].size; ++i)
		if (exchangeid == block[id].trans[i].exchangeid) {
			ret += block[id].trans[i].amount;
		}

	for (int i = 0; i < block[id].nchild; ++i)
		ret += dfs(block[id].child[i], exchangeid);
	
	return ret;
}

void syncBlockChain(int S, unsigned char chainimage[MAXSERVER][IMAGESIZE]) {

	nb = 0;

	for (int s = 0; s < S; ++s) {
		int len, hash, p = 0;
		p += get(chainimage[s] + p, len);
		while(p < len + 4) {
			int pp = p;
			p += get(chainimage[s] + p, block[nb]);
			block[nb].nchild = 0;
			block[nb].hash = calcHash(chainimage[s], pp, p - pp);
			idx[nb] = nb;
			++nb;
		}
	}
	
	mergesort(0, nb - 1);

	int p1 = 0, p2, p3 = 0;
	
	while (p1 < nb)
	{
		p2 = p1 + 1;
		while (p2 < nb && block[idx[p2]].hash == block[idx[p1]].hash)
			++p2;
		
		if (p2 - p1 > S / 2)
			idx[p3++] = idx[p1++];
		p1 = p2;
	}
	
	nb = p3;
	
	for (int i = 0; i < nb; ++i)
	{
		if (block[idx[i]].hashpreblock == 0)
			continue;
		
		int pid = getblockid(block[idx[i]].hashpreblock);
		
		block[idx[i]].parent = pid;
		block[pid].child[block[pid].nchild++] = idx[i];
	}
}

int calcAmount(int hash, int exchangeid) {
	int id = getblockid(hash);

	return dfs(id, exchangeid);
}